// Import the functions you need from the SDKs you need
import {app} from "firebase.js"
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDiyn1wNdTXaJPDLRts2EyQDdhFDe1zIRE",
  authDomain: "web40miau.firebaseapp.com",
  projectId: "web40miau",
  storageBucket: "web40miau.appspot.com",
  messagingSenderId: "123681011240",
  appId: "1:123681011240:web:2b59d4ea845ec03e95e71d",
  measurementId: "" // Corrected the property name
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const form = document.forms["formLogin"];

form.addEventListener('submit', handleForSubmit);

function handleForSubmit(event) {
  event.preventDefault();
  const email = form['correo'].value; // Assuming you have an input with name "correo"
  const password = form['password'].value;

  console.log(`Correo: ${email}, password: ${password}`);

  loginUser(email, password);
}

function loginUser(email, password) {
  console.log(`Correo: ${email}, password: ${password}`);

  app.auth().signInWithEmailAndPassword(email, password)
    .then(function(user) {
      console.log('Credenciales Correctas');
    })
    .catch(function(error) {
      console.error('Error al iniciar sesión:', error);
    });
}
