from email import EmailClient
from time import sleep
import RPi.GPIO as GPIO

def onEmailReceive(sender, subject, body):
    print("Received from: " + sender)
    print("Subject: " + subject)
    print("Body: " + body)

def onEmailSend(status):
    print("send status: " + str(status))

def send_email_on_input():
    # Configura el cliente de correo electrónico
    EmailClient.setup(
        "rasp@ti.com",  # Cambia el nombre de dominio aquí
        "ti.com",  # Cambia el dominio aquí
        "rasp",
        "password"
    )

    # Establece los manejadores de eventos
    EmailClient.onReceive(onEmailReceive)
    EmailClient.onSend(onEmailSend)

    # Envía un correo electrónico
    EmailClient.send("pc@ti.com", "Hello", "World")  # Cambia el nombre de dominio aquí

    # Revisa el correo cada cierto tiempo y verifica el estado del pin 0
    while True:
        EmailClient.receive()

        # Verifica si hay una entrada en el pin 0
        if GPIO.input(0) == GPIO.HIGH:
            print("Input detected on pin 0!")
            # Agrega aquí la llamada a la función que envía el correo
            EmailClient.send("pc@ti.com", "Input Detected", "Input detected on pin 0!")

        sleep(5)

if __name__ == "__main__":
    send_email_on_input()
